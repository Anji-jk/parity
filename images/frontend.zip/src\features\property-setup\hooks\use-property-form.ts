import { routes } from '@/constants/routes';
import { Country, State } from 'country-state-city';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert } from 'react-native';

export type PropertyValues = {
  name: string;
  address: string;
  city: string;
  state: string;
  country: string;
  countryCode: string;
  stateCode: string;
  pincode: string;
  latitude?: string;
  longitude?: string;
};

const INITIAL: PropertyValues = {
  name: '',
  address: '',
  city: '',
  state: '',
  country: 'India',
  countryCode: 'IN',
  stateCode: '',
  pincode: '',
  latitude: '',
  longitude: '',
};

export function usePropertyForm() {
  const router = useRouter();
  const [values, setValues] = useState<PropertyValues>(INITIAL);
  const [touched, setTouched] = useState(false);
  const [locating, setLocating] = useState(false);
  const error = touched && !values.name.trim() ? 'Property name is required' : undefined;

  const setField = (field: keyof PropertyValues, value: string) => setValues((previous) => ({ ...previous, [field]: value }));

  const countries = Country.getAllCountries();
  const states = values.country ? State.getStatesOfCountry(values.country) : [];

  const setCountry = (isoCode: string) => {
    const country = countries.find((c) => c.isoCode === isoCode);
    setValues((previous) => ({
      ...previous,
      countryCode: isoCode,
      country: country?.name ?? '',
      // a state from the old country is no longer valid
      stateCode: '',
      state: '',
    }));
  };

  const setState = (isoCode: string) => {
    const stateList = State.getStatesOfCountry(values.country);
    const state = stateList.find((s) => s.isoCode === isoCode);
    setValues((previous) => ({
      ...previous,
      stateCode: isoCode,
      state: state?.name ?? '',
    }));
  };


  const detectLocation = async () => {
    try {
      setLocating(true);
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.error('Location permission not granted');
        Alert.alert(
          'Location Permission Denied',
          'Please enable location permissions in your device settings to use this feature.',
          [{ text: 'OK' }]
        );
        return;
      }

      const serviceEnabled = await Location.hasServicesEnabledAsync();
      if (!serviceEnabled) {
        console.error('Location services are not enabled');
        Alert.alert(
          'Location Services Disabled',
          'Please enable location services in your device settings to use this feature.',
          [{ text: 'OK' }]
        );
        return;
      }

      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const [place] = await Location.reverseGeocodeAsync({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      });

      if (!place) {
        console.error('No address found for the current location');
        Alert.alert(
          'Location Not Found',
          'Could not determine your address from the current location. Please try again or enter the address manually.',
          [{ text: 'OK' }]
        );
        return;
      }

      // reverseGeocodeAsync returns free-text names (place.country, place.region),
      // so match them back to the isoCodes country-state-city expects.
      const matchedCountry = countries.find(
        (c) => c.name.toLowerCase() === (place.country ?? '').toLowerCase()
      );
      const countryCode = matchedCountry?.isoCode ?? values.country;
      const statesForCountry = State.getStatesOfCountry(countryCode);
      const matchedState = statesForCountry.find(
        (s) => s.name.toLowerCase() === (place.region ?? '').toLowerCase()
      );

      setValues((previous) => ({
        ...previous,
        address:
          [place.streetNumber, place.street].filter(Boolean).join(' ') ||
          place.name ||
          previous.address,
        city: place.city ?? place.subregion ?? previous.city,
        countryCode: countryCode,
        country: matchedCountry?.name ?? place.country ?? previous.country,
        stateCode: matchedState?.isoCode ?? previous.stateCode,
        state: matchedState?.name ?? place.region ?? previous.state,
        pincode: place.postalCode ?? previous.pincode,
        latitude: String(position.coords.latitude),
        longitude: String(position.coords.longitude),
      }));

    }
    catch (error) {
      console.error('Location detection failed:', error);
      Alert.alert(
        'Location Detection Failed',
        'Failed to detect your location. Please try again or enter the address manually.',
        [{ text: 'OK' }]
      );
    }
    finally {
      setLocating(false);
    }

  }


  const submit = () => {
    setTouched(true);
    if (!values.name.trim()) return;
    router.push({ pathname: routes.confirmLocation, params: values });
  };
  return {
    values,
    error,
    locating,
    countries,
    states,
    setField,
    setCountry,
    setState,
    detectLocation,
    submit,
  };
}
